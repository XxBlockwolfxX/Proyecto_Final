<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Aplicación de Gestión</title>
</head>
<body>
    <?php require_once('routes.php'); ?>
</body>
</html>
